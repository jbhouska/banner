# Banner Oh Banner
Chrome extension to quickly add classes during registration at the College of William and Mary

## Demo vid: https://sendvid.com/dbrkcteb
